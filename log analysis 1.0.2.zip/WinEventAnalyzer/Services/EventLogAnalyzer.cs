using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Xml.Linq;
using WinEventAnalyzer.Models;

namespace WinEventAnalyzer.Services;

public sealed class EventLogAnalyzer
{
    private static readonly Dictionary<int, string> IdCategoryMap = new()
    {
        [4624] = "Auth", [4625] = "Auth", [4634] = "Auth", [4647] = "Auth", [4648] = "Auth",
        [4672] = "Privilege", [4768] = "Auth", [4769] = "Auth", [4771] = "Auth", [4776] = "Auth",
        [4720] = "AccountMgmt", [4722] = "AccountMgmt", [4723] = "AccountMgmt", [4724] = "AccountMgmt",
        [4725] = "AccountMgmt", [4726] = "AccountMgmt", [4732] = "AccountMgmt", [4733] = "AccountMgmt",
        [4688] = "Process", [4689] = "Process",
        [4698] = "TaskScheduler", [4699] = "TaskScheduler", [4702] = "TaskScheduler",
        [7045] = "Service",
        [4719] = "PolicyAudit"
    };

    private static readonly Dictionary<int, (string Name, string Explain, string Stage)> IdSemanticMap = new()
    {
        [4624] = ("登录成功", "账号成功完成登录，需结合登录类型和来源判断是否正常。", "Initial Access"),
        [4625] = ("登录失败", "账号登录失败，连续出现可能是口令爆破。", "Initial Access"),
        [4634] = ("会话注销", "登录会话结束。", "Impact"),
        [4648] = ("显式凭据登录", "进程使用明确凭据尝试登录，常见于横向移动。", "Lateral Movement"),
        [4672] = ("特权登录", "新登录会话被授予高权限。", "Privilege Escalation"),
        [4688] = ("进程创建", "创建新进程，建议关注父子进程与命令行。", "Execution"),
        [4698] = ("创建计划任务", "任务创建常用于持久化。", "Persistence"),
        [4702] = ("修改计划任务", "任务被修改，可能用于权限维持。", "Persistence"),
        [4720] = ("创建用户", "系统创建了新用户。", "Persistence"),
        [4732] = ("加入安全组", "账号被加入高权限组需重点复核。", "Privilege Escalation"),
        [7045] = ("安装服务", "新服务安装常作为持久化手段。", "Persistence"),
        [4719] = ("审计策略变更", "审计策略变化可能影响取证可见性。", "Defense Evasion")
    };

    public AnalysisResult AnalyzeEvtxFile(string path)
    {
        var events = ReadAndNormalizeFromFile(path);
        return BuildResult(events);
    }

    public AnalysisResult AnalyzeLiveLogs(IEnumerable<string> logNames, int maxEventsPerLog = 3000)
    {
        try
        {
            var events = new List<NormalizedEvent>();
            var warnings = new List<string>();

            foreach (var logName in logNames)
            {
                try
                {
                    events.AddRange(ReadAndNormalizeFromLiveLog(logName, maxEventsPerLog));
                }
                catch (Exception ex)
                {
                    warnings.Add(FormatLogReadError(logName, ex));
                }
            }

            events = events.OrderBy(e => e.Timestamp).ToList();
            return BuildResult(events, warnings);
        }
        catch (Exception ex)
        {
            return BuildResult(
                Array.Empty<NormalizedEvent>(),
                new[]
                {
                    $"分析过程异常（不应出现，已记录）：{ex.Message}",
                    $"本机可用日志（供诊断）：{GetAvailableLogNamesForDiagnostics()}"
                });
        }
    }

    private static string FormatLogReadError(string logName, Exception ex)
    {
        var inner = ex.InnerException is not null ? $" 详情: {ex.InnerException.Message}" : string.Empty;
        var hint = logName.Equals("Security", StringComparison.OrdinalIgnoreCase)
            ? "（Security 通常需管理员权限；若提示找不到文件，请确认「Windows 事件日志」服务已启动。）"
            : string.Empty;
        return $"「{logName}」: {ex.Message}{inner}{hint}";
    }

    private static string GetAvailableLogNamesForDiagnostics()
    {
        try
        {
            var names = EventLog.GetEventLogs().Select(e => e.Log).Distinct().OrderBy(n => n).ToArray();
            return names.Length == 0 ? "（无）" : string.Join(", ", names.Take(40));
        }
        catch (Exception ex)
        {
            return $"枚举失败: {ex.Message}";
        }
    }

    private static AnalysisResult BuildResult(IReadOnlyList<NormalizedEvent> events, IReadOnlyList<string>? warnings = null)
    {
        var categoryCounts = events
            .GroupBy(e => e.Category)
            .ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase);

        var idCounts = events
            .GroupBy(e => e.EventId)
            .ToDictionary(g => g.Key, g => g.Count());

        var clusters = BuildClusters(events);
        var findings = BuildRiskFindings(events);
        var sessions = BuildSessions(events, findings);
        var summary = BuildSummary(events, findings, sessions);

        return new AnalysisResult
        {
            Events = events,
            Clusters = clusters,
            Sessions = sessions,
            RiskFindings = findings,
            Summary = summary,
            CategoryCounts = categoryCounts,
            EventIdCounts = idCounts,
            Warnings = warnings ?? Array.Empty<string>()
        };
    }

    private static List<NormalizedEvent> ReadAndNormalizeFromFile(string path)
    {
        var result = new List<NormalizedEvent>();
        var query = new EventLogQuery(path, PathType.FilePath);
        using var reader = new EventLogReader(query);

        for (EventRecord? record = reader.ReadEvent(); record is not null; record = reader.ReadEvent())
        {
            using (record)
            {
                result.Add(Normalize(record));
            }
        }

        return result.OrderBy(e => e.Timestamp).ToList();
    }

    private static List<NormalizedEvent> ReadAndNormalizeFromLiveLog(string logName, int maxEvents)
    {
        var result = new List<NormalizedEvent>();

        // 1) 新版 API（EventLogReader）。部分环境会报「找不到文件」等错误。
        try
        {
            ReadLiveLogInternal(logName, maxEvents, reverse: true, result);
            return result;
        }
        catch
        {
            result.Clear();
        }

        try
        {
            ReadLiveLogInternal(logName, maxEvents, reverse: false, result);
            return result;
        }
        catch
        {
            result.Clear();
        }

        // 2) 备用：经典 EventLog API（在 EventLogReader 失败的机器上往往能读 Application/System）
        return ReadViaLegacyEventLog(logName, maxEvents);
    }

    private static List<NormalizedEvent> ReadViaLegacyEventLog(string logName, int maxEvents)
    {
        if (!EventLog.Exists(logName))
        {
            throw new InvalidOperationException($"日志「{logName}」不存在（EventLog.Exists=false）。");
        }

        var buffer = new List<NormalizedEvent>(Math.Min(maxEvents, 512));
        using var log = new EventLog(logName);
        var total = log.Entries.Count;
        var taken = 0;
        for (var i = total - 1; i >= 0 && taken < maxEvents; i--)
        {
            try
            {
                var entry = log.Entries[i];
                buffer.Add(NormalizeFromLegacyEntry(entry, logName));
                taken++;
            }
            catch
            {
                // 单条损坏则跳过
            }
        }

        return buffer.OrderBy(e => e.Timestamp).ToList();
    }

    private static NormalizedEvent NormalizeFromLegacyEntry(EventLogEntry entry, string logName)
    {
        // .NET 的 EventLogEntry 无 EventId 属性时，用 InstanceId 低 16 位作为事件 ID（与旧版行为一致）
        var eventId = (int)(entry.InstanceId & 0xFFFF);
        var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["Message"] = entry.Message ?? string.Empty,
            ["Source"] = entry.Source ?? string.Empty
        };

        var category = ResolveCategory(eventId, entry.Source ?? string.Empty, logName, fields);
        var user = entry.UserName ?? string.Empty;
        var srcIp = string.Empty;
        var logonId = string.Empty;
        var correlation = BuildCorrelationKey(category, user, srcIp, logonId, fields);

        return new NormalizedEvent(
            Timestamp: entry.TimeGenerated,
            EventId: eventId,
            EventName: ResolveEventName(eventId),
            EventExplanation: ResolveEventExplanation(eventId),
            Provider: entry.Source ?? string.Empty,
            Channel: logName,
            Computer: entry.MachineName ?? string.Empty,
            Level: entry.EntryType.ToString(),
            Category: category,
            Stage: ResolveStage(eventId, category),
            RiskScore: CalculateEventRisk(eventId, fields, user, srcIp),
            Summary: BuildEventSummary(eventId, category, user, srcIp, fields),
            User: user,
            SourceIp: srcIp,
            LogonId: logonId,
            CorrelationKey: correlation,
            Fields: fields);
    }

    private static void ReadLiveLogInternal(string logName, int maxEvents, bool reverse, List<NormalizedEvent> sink)
    {
        var query = new EventLogQuery(logName, PathType.LogName)
        {
            ReverseDirection = reverse,
            TolerateQueryErrors = true
        };

        using var reader = new EventLogReader(query);
        var count = 0;
        if (reverse)
        {
            for (EventRecord? record = reader.ReadEvent(); record is not null && count < maxEvents; record = reader.ReadEvent())
            {
                using (record)
                {
                    sink.Add(Normalize(record));
                    count++;
                }
            }

            return;
        }

        // 正向读取：取时间排序后的最后 maxEvents 条（近似“最近”）
        var buffer = new List<NormalizedEvent>(maxEvents + 1);
        for (EventRecord? record = reader.ReadEvent(); record is not null; record = reader.ReadEvent())
        {
            using (record)
            {
                buffer.Add(Normalize(record));
                if (buffer.Count > maxEvents)
                {
                    buffer.RemoveAt(0);
                }
            }
        }

        sink.AddRange(buffer);
    }

    private static NormalizedEvent Normalize(EventRecord record)
    {
        var xml = record.ToXml();
        var fields = ParseEventData(xml);
        var eventId = record.Id;
        var category = ResolveCategory(eventId, record.ProviderName ?? string.Empty, record.LogName ?? string.Empty, fields);

        var user = GetFirst(fields, "TargetUserName", "SubjectUserName", "AccountName", "User");
        var srcIp = GetFirst(fields, "IpAddress", "ClientAddress", "SourceNetworkAddress");
        var logonId = GetFirst(fields, "TargetLogonId", "SubjectLogonId", "LogonID");
        var correlation = BuildCorrelationKey(category, user, srcIp, logonId, fields);

        return new NormalizedEvent(
            Timestamp: record.TimeCreated ?? DateTime.MinValue,
            EventId: eventId,
            EventName: ResolveEventName(eventId),
            EventExplanation: ResolveEventExplanation(eventId),
            Provider: record.ProviderName ?? string.Empty,
            Channel: record.LogName ?? string.Empty,
            Computer: record.MachineName ?? string.Empty,
            Level: record.LevelDisplayName ?? string.Empty,
            Category: category,
            Stage: ResolveStage(eventId, category),
            RiskScore: CalculateEventRisk(eventId, fields, user, srcIp),
            Summary: BuildEventSummary(eventId, category, user, srcIp, fields),
            User: user,
            SourceIp: srcIp,
            LogonId: logonId,
            CorrelationKey: correlation,
            Fields: fields);
    }

    private static Dictionary<string, string> ParseEventData(string xml)
    {
        var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            var doc = XDocument.Parse(xml);
            var eventData = doc.Root?.Element(doc.Root.GetDefaultNamespace() + "EventData");
            if (eventData is null)
            {
                return dict;
            }

            foreach (var data in eventData.Elements(doc.Root!.GetDefaultNamespace() + "Data"))
            {
                var name = data.Attribute("Name")?.Value;
                var value = data.Value?.Trim() ?? string.Empty;
                if (string.IsNullOrWhiteSpace(name))
                {
                    continue;
                }

                dict[name] = value;
            }
        }
        catch
        {
            // Ignore malformed XML for resilience.
        }

        return dict;
    }

    private static string ResolveCategory(int eventId, string provider, string channel, IReadOnlyDictionary<string, string> fields)
    {
        if (IdCategoryMap.TryGetValue(eventId, out var mapped))
        {
            return mapped;
        }

        var keyBlob = $"{provider} {channel} {string.Join(' ', fields.Keys)}".ToLowerInvariant();
        if (keyBlob.Contains("logon") || keyBlob.Contains("auth") || keyBlob.Contains("kerberos") || keyBlob.Contains("ntlm"))
        {
            return "Auth";
        }
        if (keyBlob.Contains("account") || keyBlob.Contains("user") || keyBlob.Contains("group"))
        {
            return "AccountMgmt";
        }
        if (keyBlob.Contains("process") || keyBlob.Contains("commandline"))
        {
            return "Process";
        }
        if (keyBlob.Contains("service"))
        {
            return "Service";
        }
        if (keyBlob.Contains("task"))
        {
            return "TaskScheduler";
        }
        if (keyBlob.Contains("policy") || keyBlob.Contains("audit"))
        {
            return "PolicyAudit";
        }

        return "Other";
    }

    private static string BuildCorrelationKey(string category, string user, string srcIp, string logonId, IReadOnlyDictionary<string, string> fields)
    {
        var host = GetFirst(fields, "WorkstationName", "Computer", "MachineName");
        return $"{category}|{user}|{srcIp}|{host}|{logonId}";
    }

    private static string BuildEventSummary(int eventId, string category, string user, string srcIp, IReadOnlyDictionary<string, string> fields)
    {
        var status = GetFirst(fields, "Status", "SubStatus");
        var process = GetFirst(fields, "ProcessName", "NewProcessName", "CommandLine");
        return $"[{category}] ID={eventId}, User={Safe(user)}, SrcIP={Safe(srcIp)}, Status={Safe(status)}, Process={Safe(process)}";
    }

    private static List<EventCluster> BuildClusters(IReadOnlyList<NormalizedEvent> orderedEvents)
    {
        var clusters = new List<EventCluster>();
        var window = TimeSpan.FromMinutes(5);

        foreach (var grouping in orderedEvents.GroupBy(e => e.CorrelationKey))
        {
            var current = new List<NormalizedEvent>();
            DateTime start = DateTime.MinValue;
            DateTime last = DateTime.MinValue;

            foreach (var item in grouping.OrderBy(e => e.Timestamp))
            {
                if (current.Count == 0)
                {
                    current.Add(item);
                    start = item.Timestamp;
                    last = item.Timestamp;
                    continue;
                }

                if (item.Timestamp - last <= window)
                {
                    current.Add(item);
                    last = item.Timestamp;
                    continue;
                }

                clusters.Add(ToCluster(current, start, last));
                current = [item];
                start = item.Timestamp;
                last = item.Timestamp;
            }

            if (current.Count > 0)
            {
                clusters.Add(ToCluster(current, start, last));
            }
        }

        return clusters.OrderBy(c => c.StartTime).ToList();
    }

    private static EventCluster ToCluster(List<NormalizedEvent> events, DateTime start, DateTime end)
    {
        var first = events[0];
        var ids = events.Select(e => e.EventId).Distinct().OrderBy(id => id).ToArray();
        var narrative = BuildNarrative(events);

        return new EventCluster
        {
            ClusterType = DetectClusterType(events),
            Category = first.Category,
            CorrelationKey = first.CorrelationKey,
            StartTime = start,
            EndTime = end,
            Count = events.Count,
            EventIds = ids,
            PrimaryUser = first.User,
            PrimarySourceIp = first.SourceIp,
            Narrative = narrative,
            Events = events
        };
    }

    private static string DetectClusterType(IReadOnlyCollection<NormalizedEvent> events)
    {
        var ids = events.Select(e => e.EventId).ToHashSet();
        if (ids.Contains(4625) && ids.Contains(4624))
        {
            return "FailedThenSuccess";
        }
        if (ids.Contains(4625))
        {
            return "FailedLogonSeries";
        }
        if (ids.Contains(4624) && ids.Contains(4672))
        {
            return "PrivilegedLogon";
        }
        if (ids.Contains(4688))
        {
            return "ProcessBurst";
        }

        return "General";
    }

    private static string BuildNarrative(IReadOnlyCollection<NormalizedEvent> events)
    {
        var first = events.First();
        var ids = string.Join(",", events.Select(e => e.EventId).Distinct().OrderBy(id => id));
        return $"{first.Timestamp:yyyy-MM-dd HH:mm:ss} - {events.Last().Timestamp:HH:mm:ss}, " +
               $"category={first.Category}, events={events.Count}, ids=[{ids}], user={Safe(first.User)}, ip={Safe(first.SourceIp)}";
    }

    private static List<SessionChain> BuildSessions(IReadOnlyList<NormalizedEvent> events, IReadOnlyList<RiskFinding> findings)
    {
        var sessions = new List<SessionChain>();
        foreach (var group in events.GroupBy(BuildSessionKey))
        {
            var list = group.OrderBy(e => e.Timestamp).ToList();
            if (list.Count == 0)
            {
                continue;
            }

            var stageSummary = string.Join(" -> ", list.Select(e => e.Stage).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct());
            var maxRisk = list.Max(e => e.RiskScore);
            var sessionFindings = findings.Where(f =>
                    f.User.Equals(list[0].User, StringComparison.OrdinalIgnoreCase) &&
                    (string.IsNullOrWhiteSpace(f.SourceIp) || f.SourceIp.Equals(list[0].SourceIp, StringComparison.OrdinalIgnoreCase)))
                .ToList();
            var conclusion = BuildSessionConclusion(maxRisk, sessionFindings.Count, list);

            sessions.Add(new SessionChain
            {
                SessionKey = group.Key,
                StartTime = list.First().Timestamp,
                EndTime = list.Last().Timestamp,
                User = list[0].User,
                SourceIp = list[0].SourceIp,
                EventCount = list.Count,
                MaxRiskScore = maxRisk,
                StageSummary = stageSummary,
                Conclusion = conclusion,
                Events = list
            });
        }

        return sessions.OrderByDescending(s => s.MaxRiskScore).ThenByDescending(s => s.StartTime).ToList();
    }

    private static InvestigationSummary BuildSummary(
        IReadOnlyList<NormalizedEvent> events,
        IReadOnlyList<RiskFinding> findings,
        IReadOnlyList<SessionChain> sessions)
    {
        var topRisk = sessions.FirstOrDefault()?.MaxRiskScore ?? 0;
        var ruleWeight = Math.Min(35, findings.Count * 5);
        var score = Math.Min(100, topRisk + ruleWeight);
        var verdict = score >= 80 ? "高危：疑似入侵链路" : score >= 50 ? "可疑：建议人工复核" : "低危：暂未发现明显攻击链";

        var evidence = new List<string>();
        var topFindings = findings.Take(3).ToList();
        evidence.AddRange(topFindings.Select(f => $"{f.RuleName} 命中，用户={Safe(f.User)}，源IP={Safe(f.SourceIp)}"));

        var topSession = sessions.FirstOrDefault();
        if (topSession is not null)
        {
            evidence.Add($"最高风险会话：{Safe(topSession.User)} / {Safe(topSession.SourceIp)}，阶段={topSession.StageSummary}");
        }

        while (evidence.Count < 3)
        {
            evidence.Add("暂无更多关键证据。");
        }

        return new InvestigationSummary
        {
            Verdict = verdict,
            OverallScore = score,
            KeyEvidence1 = evidence[0],
            KeyEvidence2 = evidence[1],
            KeyEvidence3 = evidence[2]
        };
    }

    private static List<RiskFinding> BuildRiskFindings(IReadOnlyList<NormalizedEvent> events)
    {
        var findings = new List<RiskFinding>();
        findings.AddRange(DetectBruteForce(events));
        findings.AddRange(DetectOffHoursSuccess(events));
        findings.AddRange(DetectAccountChangeChain(events));
        return findings.OrderByDescending(f => f.StartTime).ToList();
    }

    private static IEnumerable<RiskFinding> DetectBruteForce(IReadOnlyList<NormalizedEvent> events)
    {
        var window = TimeSpan.FromMinutes(10);
        var failures = events.Where(e => e.EventId == 4625).OrderBy(e => e.Timestamp).ToList();

        foreach (var group in failures.GroupBy(e => $"{e.User}|{e.SourceIp}"))
        {
            var list = group.ToList();
            var left = 0;
            for (var right = 0; right < list.Count; right++)
            {
                while (list[right].Timestamp - list[left].Timestamp > window)
                {
                    left++;
                }

                var count = right - left + 1;
                if (count >= 5)
                {
                    yield return new RiskFinding
                    {
                        RuleName = "BruteForceAttempt",
                        Severity = "High",
                        StartTime = list[left].Timestamp,
                        EndTime = list[right].Timestamp,
                        User = list[right].User,
                        SourceIp = list[right].SourceIp,
                        Count = count,
                        Description = $"10分钟内登录失败 {count} 次，疑似暴力破解。"
                    };
                    left = right + 1;
                }
            }
        }
    }

    private static IEnumerable<RiskFinding> DetectOffHoursSuccess(IReadOnlyList<NormalizedEvent> events)
    {
        var baselineHours = events
            .Where(e => e.EventId == 4624 && !string.IsNullOrWhiteSpace(e.User))
            .GroupBy(e => e.User)
            .ToDictionary(g => g.Key, g => g.GroupBy(e => e.Timestamp.Hour).OrderByDescending(h => h.Count()).Take(2).Select(h => h.Key).ToHashSet());

        var logons = events.Where(e => e.EventId == 4624);
        foreach (var item in logons)
        {
            var hour = item.Timestamp.Hour;
            var baselineHit = baselineHours.TryGetValue(item.User, out var hset) && hset.Contains(hour);
            if ((hour is >= 0 and < 6 || hour >= 22) && !baselineHit)
            {
                yield return new RiskFinding
                {
                    RuleName = "OffHoursLogon",
                    Severity = "Medium",
                    StartTime = item.Timestamp,
                    EndTime = item.Timestamp,
                    User = item.User,
                    SourceIp = item.SourceIp,
                    Count = 1,
                    Description = "非工作时段登录成功（22:00-06:00）。"
                };
            }
        }
    }

    private static IEnumerable<RiskFinding> DetectAccountChangeChain(IReadOnlyList<NormalizedEvent> events)
    {
        var interesting = new HashSet<int> { 4720, 4722, 4732 };
        var accountEvents = events.Where(e => interesting.Contains(e.EventId)).OrderBy(e => e.Timestamp);
        var groups = accountEvents.GroupBy(e => GetFirst(e.Fields, "TargetUserName", "MemberName", "AccountName"));

        foreach (var group in groups)
        {
            if (string.IsNullOrWhiteSpace(group.Key))
            {
                continue;
            }

            var list = group.ToList();
            for (var i = 0; i < list.Count; i++)
            {
                var start = list[i].Timestamp;
                var end = start.AddMinutes(30);
                var windowEvents = list.Where(e => e.Timestamp >= start && e.Timestamp <= end).ToList();
                var ids = windowEvents.Select(e => e.EventId).ToHashSet();
                if (ids.Contains(4720) && ids.Contains(4732))
                {
                    yield return new RiskFinding
                    {
                        RuleName = "AccountChangeChain",
                        Severity = "High",
                        StartTime = windowEvents.First().Timestamp,
                        EndTime = windowEvents.Last().Timestamp,
                        User = group.Key,
                        SourceIp = windowEvents.Select(e => e.SourceIp).FirstOrDefault(ip => !string.IsNullOrWhiteSpace(ip)) ?? string.Empty,
                        Count = windowEvents.Count,
                        Description = "30分钟内出现账号创建并加入组，需人工复核是否为异常提权链。"
                    };
                    break;
                }
            }
        }
    }

    private static string ResolveEventName(int eventId)
        => IdSemanticMap.TryGetValue(eventId, out var sem) ? sem.Name : $"事件 {eventId}";

    private static string ResolveEventExplanation(int eventId)
        => IdSemanticMap.TryGetValue(eventId, out var sem) ? sem.Explain : "该事件暂未录入详细解释，已按通用规则分类。";

    private static string ResolveStage(int eventId, string category)
        => IdSemanticMap.TryGetValue(eventId, out var sem)
            ? sem.Stage
            : category switch
            {
                "Auth" => "Initial Access",
                "Process" => "Execution",
                "Service" or "TaskScheduler" => "Persistence",
                "Privilege" => "Privilege Escalation",
                _ => "Discovery"
            };

    private static int CalculateEventRisk(int eventId, IReadOnlyDictionary<string, string> fields, string user, string srcIp)
    {
        var score = eventId switch
        {
            4672 => 70,
            7045 => 80,
            4698 or 4702 => 75,
            4720 or 4732 => 78,
            4625 => 45,
            4624 => 20,
            _ => 30
        };

        if (eventId == 4624 && !string.IsNullOrWhiteSpace(srcIp) && srcIp != "::1" && srcIp != "127.0.0.1" && srcIp != "-")
        {
            score += 8;
        }
        if (!string.IsNullOrWhiteSpace(GetFirst(fields, "CommandLine")) || !string.IsNullOrWhiteSpace(GetFirst(fields, "NewProcessName")))
        {
            score += 8;
        }
        if (string.IsNullOrWhiteSpace(user) || user.Equals("SYSTEM", StringComparison.OrdinalIgnoreCase))
        {
            score -= 6;
        }

        return Math.Clamp(score, 1, 100);
    }

    private static string BuildSessionKey(NormalizedEvent e)
    {
        if (!string.IsNullOrWhiteSpace(e.LogonId) && e.LogonId != "0x0")
        {
            return $"logon:{e.LogonId}";
        }

        return $"fallback:{e.User}|{e.SourceIp}|{e.Timestamp:yyyyMMddHH}";
    }

    private static string BuildSessionConclusion(int maxRisk, int findingCount, IReadOnlyList<NormalizedEvent> events)
    {
        if (maxRisk >= 80 || findingCount >= 2)
        {
            return "高风险会话，建议立即复核该用户与源IP。";
        }
        if (events.Any(e => e.EventId == 4625) && events.Any(e => e.EventId == 4624))
        {
            return "存在失败后成功登录，建议核查口令安全性。";
        }
        return "未发现明显高危链路。";
    }

    private static string GetFirst(IReadOnlyDictionary<string, string> fields, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (fields.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value) && value != "-")
            {
                return value;
            }
        }

        return string.Empty;
    }

    private static string Safe(string value) => string.IsNullOrWhiteSpace(value) ? "N/A" : value;
}
