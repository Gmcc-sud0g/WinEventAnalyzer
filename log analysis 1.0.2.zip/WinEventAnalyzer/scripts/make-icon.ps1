Add-Type -AssemblyName System.Drawing
$icon = [System.Drawing.SystemIcons]::Shield
$fs = [System.IO.File]::Open("app.ico", [System.IO.FileMode]::Create)
$icon.Save($fs)
$fs.Close()
