namespace WinEventAnalyzer.Models;

public sealed class EventCluster
{
    public required string ClusterType { get; init; }
    public required string Category { get; init; }
    public required string CorrelationKey { get; init; }
    public required DateTime StartTime { get; init; }
    public required DateTime EndTime { get; init; }
    public required int Count { get; init; }
    public required IReadOnlyCollection<int> EventIds { get; init; }
    public required string PrimaryUser { get; init; }
    public required string PrimarySourceIp { get; init; }
    public required string Narrative { get; init; }
    public required IReadOnlyList<NormalizedEvent> Events { get; init; }
}
