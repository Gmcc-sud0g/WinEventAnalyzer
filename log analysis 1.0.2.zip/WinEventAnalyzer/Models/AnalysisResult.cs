namespace WinEventAnalyzer.Models;

public sealed class AnalysisResult
{
    public required IReadOnlyList<NormalizedEvent> Events { get; init; }
    public required IReadOnlyList<EventCluster> Clusters { get; init; }
    public required IReadOnlyList<SessionChain> Sessions { get; init; }
    public required IReadOnlyList<RiskFinding> RiskFindings { get; init; }
    public required InvestigationSummary Summary { get; init; }
    public required IReadOnlyDictionary<string, int> CategoryCounts { get; init; }
    public required IReadOnlyDictionary<int, int> EventIdCounts { get; init; }

    /// <summary>读取本机日志时的警告（例如某通道无法打开）。</summary>
    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}
