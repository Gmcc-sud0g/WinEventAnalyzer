namespace WinEventAnalyzer.Models;

public sealed class InvestigationSummary
{
    public required string Verdict { get; init; }
    public required int OverallScore { get; init; }
    public required string KeyEvidence1 { get; init; }
    public required string KeyEvidence2 { get; init; }
    public required string KeyEvidence3 { get; init; }
}
