namespace WinEventAnalyzer.Models;

public sealed class SessionChain
{
    public required string SessionKey { get; init; }
    public required DateTime StartTime { get; init; }
    public required DateTime EndTime { get; init; }
    public required string User { get; init; }
    public required string SourceIp { get; init; }
    public required int EventCount { get; init; }
    public required int MaxRiskScore { get; init; }
    public required string StageSummary { get; init; }
    public required string Conclusion { get; init; }
    public required IReadOnlyList<NormalizedEvent> Events { get; init; }
}
