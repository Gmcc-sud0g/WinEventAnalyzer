namespace WinEventAnalyzer.Models;

public sealed record NormalizedEvent(
    DateTime Timestamp,
    int EventId,
    string EventName,
    string EventExplanation,
    string Provider,
    string Channel,
    string Computer,
    string Level,
    string Category,
    string Stage,
    int RiskScore,
    string Summary,
    string User,
    string SourceIp,
    string LogonId,
    string CorrelationKey,
    IReadOnlyDictionary<string, string> Fields);
