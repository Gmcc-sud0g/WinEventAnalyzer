namespace WinEventAnalyzer.Models;

public sealed class RiskFinding
{
    public required string RuleName { get; init; }
    public required string Severity { get; init; }
    public required DateTime StartTime { get; init; }
    public required DateTime EndTime { get; init; }
    public required string User { get; init; }
    public required string SourceIp { get; init; }
    public required int Count { get; init; }
    public required string Description { get; init; }
}
