using System.Reflection;
using System.Windows;
using Microsoft.Win32;
using WinEventAnalyzer.Models;
using WinEventAnalyzer.Services;

namespace WinEventAnalyzer;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly EventLogAnalyzer _analyzer = new();
    private AnalysisResult? _currentResult;

    public MainWindow()
    {
        InitializeComponent();
        var ver = typeof(MainWindow).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion
                  ?? typeof(MainWindow).Assembly.GetName().Version?.ToString();
        if (!string.IsNullOrWhiteSpace(ver))
        {
            Title = $"Windows 事件日志分析器 v{ver}";
        }

        CategoryFilterComboBox.ItemsSource = new[] { "全部" };
        CategoryFilterComboBox.SelectedIndex = 0;
    }

    private async void SelectFileButton_OnClick(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "选择 Windows 事件日志文件",
            Filter = "Event Log (*.evtx)|*.evtx|All files (*.*)|*.*"
        };

        if (dialog.ShowDialog() != true)
        {
            return;
        }

        SelectFileButton.IsEnabled = false;
        StatusTextBlock.Text = "正在分析，请稍候...";

        try
        {
            var result = await Task.Run(() => _analyzer.AnalyzeEvtxFile(dialog.FileName));
            BindResult(result);
            StatusTextBlock.Text = $"分析完成：{dialog.FileName}";
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "分析失败";
            MessageBox.Show(this, ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            SelectFileButton.IsEnabled = true;
        }
    }

    private async void AnalyzeLiveButton_OnClick(object sender, RoutedEventArgs e)
    {
        SelectFileButton.IsEnabled = false;
        AnalyzeLiveButton.IsEnabled = false;
        StatusTextBlock.Text = "正在读取本机 Security/System/Application...";

        try
        {
            var result = await Task.Run(() => _analyzer.AnalyzeLiveLogs(["Security", "System", "Application"]));
            try
            {
                BindResult(result);
            }
            catch (Exception bindEx)
            {
                StatusTextBlock.Text = "界面绑定失败";
                MessageBox.Show(
                    this,
                    $"分析数据已生成，但界面更新失败：{bindEx.Message}",
                    "错误",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            if (result.Events.Count == 0)
            {
                StatusTextBlock.Text = "未能读取任何事件。";
                var detail = result.Warnings.Count > 0
                    ? string.Join("\n", result.Warnings)
                    : "请确认「Windows 事件日志」服务已启动，并以管理员身份运行本程序后重试。";
                MessageBox.Show(this, detail, "无法读取本机日志", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (result.Warnings.Count > 0)
            {
                StatusTextBlock.Text = "分析完成（部分日志未读取，见弹窗说明）";
                MessageBox.Show(
                    this,
                    "以下日志未能读取，已跳过并继续分析其余日志：\n\n" + string.Join("\n\n", result.Warnings),
                    "提示",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
            else
            {
                StatusTextBlock.Text = "本机实时日志分析完成。";
            }
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "实时分析失败";
            MessageBox.Show(this, $"读取本机日志失败：{ex.Message}\n提示：请以管理员身份运行；并确认「Windows 事件日志」服务已启动。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            SelectFileButton.IsEnabled = true;
            AnalyzeLiveButton.IsEnabled = true;
        }
    }

    private void ApplyFilterButton_OnClick(object sender, RoutedEventArgs e)
    {
        ApplyFilters();
    }

    private void ResetFilterButton_OnClick(object sender, RoutedEventArgs e)
    {
        UserFilterTextBox.Text = string.Empty;
        IpFilterTextBox.Text = string.Empty;
        CategoryFilterComboBox.SelectedIndex = 0;
        StartDatePicker.SelectedDate = null;
        EndDatePicker.SelectedDate = null;
        ApplyFilters();
    }

    private void BindResult(AnalysisResult result)
    {
        _currentResult = result;
        var categories = new List<string> { "全部" };
        categories.AddRange(result.CategoryCounts.Keys.OrderBy(c => c));
        CategoryFilterComboBox.ItemsSource = categories;
        CategoryFilterComboBox.SelectedIndex = 0;
        ApplyFilters();
    }

    private void ApplyFilters()
    {
        if (_currentResult is null)
        {
            return;
        }

        var user = UserFilterTextBox.Text?.Trim() ?? string.Empty;
        var ip = IpFilterTextBox.Text?.Trim() ?? string.Empty;
        var category = CategoryFilterComboBox.SelectedItem?.ToString() ?? "全部";
        var start = StartDatePicker.SelectedDate?.Date;
        var end = EndDatePicker.SelectedDate?.Date.AddDays(1).AddTicks(-1);

        var filteredEvents = _currentResult.Events
            .Where(e => string.IsNullOrWhiteSpace(user) || e.User.Contains(user, StringComparison.OrdinalIgnoreCase))
            .Where(e => string.IsNullOrWhiteSpace(ip) || e.SourceIp.Contains(ip, StringComparison.OrdinalIgnoreCase))
            .Where(e => category == "全部" || e.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
            .Where(e => start is null || e.Timestamp >= start.Value)
            .Where(e => end is null || e.Timestamp <= end.Value)
            .ToList();

        var allowedKeys = filteredEvents.Select(e => e.CorrelationKey).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var filteredClusters = _currentResult.Clusters
            .Where(c => allowedKeys.Contains(c.CorrelationKey))
            .ToList();

        var filteredFindings = _currentResult.RiskFindings
            .Where(f => string.IsNullOrWhiteSpace(user) || f.User.Contains(user, StringComparison.OrdinalIgnoreCase))
            .Where(f => string.IsNullOrWhiteSpace(ip) || f.SourceIp.Contains(ip, StringComparison.OrdinalIgnoreCase))
            .Where(f => start is null || f.StartTime >= start.Value)
            .Where(f => end is null || f.EndTime <= end.Value)
            .ToList();

        var filteredSessions = _currentResult.Sessions
            .Where(s => string.IsNullOrWhiteSpace(user) || s.User.Contains(user, StringComparison.OrdinalIgnoreCase))
            .Where(s => string.IsNullOrWhiteSpace(ip) || s.SourceIp.Contains(ip, StringComparison.OrdinalIgnoreCase))
            .Where(s => start is null || s.StartTime >= start.Value)
            .Where(s => end is null || s.EndTime <= end.Value)
            .ToList();

        var overallRisk = filteredSessions.Count == 0 ? 0 : filteredSessions.Max(s => s.MaxRiskScore);
        var verdict = overallRisk >= 80 ? "高危：疑似入侵链路" : overallRisk >= 50 ? "可疑：建议人工复核" : "低危：暂未发现明显攻击链";

        TotalEventsTextBlock.Text = filteredEvents.Count.ToString();
        TotalClustersTextBlock.Text = filteredClusters.Count.ToString();
        TotalEventTypeTextBlock.Text = filteredEvents.Select(e => e.EventId).Distinct().Count().ToString();
        OverallRiskScoreTextBlock.Text = overallRisk.ToString();

        CategoryGrid.ItemsSource = filteredEvents
            .GroupBy(e => e.Category)
            .OrderByDescending(g => g.Count())
            .Select(g => new CategoryRow(g.Key, g.Count()))
            .ToList();
        ClusterGrid.ItemsSource = filteredClusters;
        TimelineGrid.ItemsSource = filteredEvents;
        RiskGrid.ItemsSource = filteredFindings;
        SessionGrid.ItemsSource = filteredSessions;

        var evidence = BuildEvidence(filteredFindings, filteredSessions);
        VerdictTextBlock.Text = verdict;
        Evidence1TextBlock.Text = evidence[0];
        Evidence2TextBlock.Text = evidence[1];
        Evidence3TextBlock.Text = evidence[2];
    }

    private static List<string> BuildEvidence(IReadOnlyList<RiskFinding> findings, IReadOnlyList<SessionChain> sessions)
    {
        var list = new List<string>();
        list.AddRange(findings
            .OrderByDescending(f => SeverityRank(f.Severity))
            .ThenByDescending(f => f.StartTime)
            .Take(2)
            .Select(f => $"{f.RuleName}: 用户={Safe(f.User)}, 源IP={Safe(f.SourceIp)}, 描述={f.Description}"));

        var topSession = sessions.OrderByDescending(s => s.MaxRiskScore).FirstOrDefault();
        if (topSession is not null)
        {
            list.Add($"最高风险会话: 用户={Safe(topSession.User)}, 源IP={Safe(topSession.SourceIp)}, 阶段={topSession.StageSummary}");
        }

        while (list.Count < 3)
        {
            list.Add("暂无更多关键证据。");
        }

        return list;
    }

    private static int SeverityRank(string severity) =>
        severity.Equals("High", StringComparison.OrdinalIgnoreCase) ? 3 :
        severity.Equals("Medium", StringComparison.OrdinalIgnoreCase) ? 2 :
        severity.Equals("Low", StringComparison.OrdinalIgnoreCase) ? 1 : 0;

    private static string Safe(string value) => string.IsNullOrWhiteSpace(value) ? "N/A" : value;
}

public sealed record CategoryRow(string Category, int Count);